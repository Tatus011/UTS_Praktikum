<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register - Flowers & Co</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container"><br>
        <div class="col-md-4 col-md-offset-4">
            <h2 class="text-center"><b>Flowers & Co</b><br>Aplikasi Toko Bunga</h3>
            <hr>
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <b>Sukses!</b> <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('actionregister')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="name" class="form-control" placeholder="Nama" required="">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" required="">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" required="">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Register</button>
                <hr>
                <p class="text-center">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Login</a> sekarang!</p>
            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\praktikum-uts\resources\views/bunga/register.blade.php ENDPATH**/ ?>