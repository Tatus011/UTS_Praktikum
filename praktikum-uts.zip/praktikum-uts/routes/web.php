<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/halaman', [ProductController::class, 'halaman'])->name('halaman.home');


// Route untuk menampilkan halaman registrasi
Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
// Route untuk menangani proses pendaftaran
Route::post('/register', [RegisterController::class, 'register'])->name('actionregister');


Route::get('/', [LoginController::class, 'login'])->name('login');
Route::post('actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');
Route::get('home', [HomeController::class, 'index'])->name('home')->middleware('auth');
Route::get('actionlogout', [LoginController::class, 'actionlogout'])->name('actionlogout')->middleware('auth');


Route::get('/posts', [PostController::class, 'index'])->name('posts');
//route resource
Route::resource('/posts', \App\Http\Controllers\PostController::class);

