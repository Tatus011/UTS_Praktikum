<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Pastikan untuk mengganti ini dengan model yang tepat untuk data pengguna (User).

class RegisterController extends Controller
{
    // Menampilkan halaman registrasi
    public function showRegistrationForm()
    {
        return view('bunga.register'); // Sesuaikan dengan nama tampilan (view) yang kamu gunakan untuk registrasi.
    }

    // Menangani proses registrasi
    public function register(Request $request)
    {
        // Validasi data yang diterima dari form registrasi
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users', // Pastikan 'users' mengacu pada nama tabel pengguna yang benar
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Simpan data pengguna baru ke dalam database
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        // Jika registrasi berhasil, redirect ke halaman login atau ke halaman lain yang kamu tentukan.
        if ($user) {
            return redirect()->route('login')->with('success', 'Registrasi berhasil! Silakan login.');
        } else {
            // Jika ada kesalahan dalam registrasi, redirect kembali ke halaman registrasi dengan pesan error
            return back()->with('error', 'Registrasi gagal. Silakan coba lagi.');
        }
    }
}
