@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="my-4">Daftar Produk</h1>

        <div class="row">
            @foreach($product as $product)
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="{{ $product->image }}" class="card-img-top" alt="{{ $product->nama }}">
                        <div class="card-body">
                            <h5 class="card-title">{{ $product->nama }}</h5>
                            <p class="card-text">Harga: {{ $product->harga }}</p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
